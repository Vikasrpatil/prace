const mongoose = require('mongoose');


const teamSchema = new mongoose.Schema({
    chinese_name: {
        required: true,
        type: String
    },
    english_name: {
        required: true,
        type: String
    },
    team_nature: {
        required: true,
        type: String
    },
    player_list: {
        required: true,
        type: Array
    },

    match_record: {
        required: true,
        type: String
    },
    activity: {
        required: true,
        type: String
    },
  })

  module.exports = mongoose.model('team', teamSchema)