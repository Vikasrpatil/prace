const mongoose = require('mongoose');


const coachprofileSchema = new mongoose.Schema({
    team_nature: {
        required: true,
        type: String
    },
    location: {
        required: true,
        type: String
    },

    match: {
        required: true,
        type: String
    },
    activity_type: {
        required: true,
        type: String
    },
    activity: {
        required: true,
        type: String
    },
    approval_status: {
        required: true,
        type: String
    },
    request_list: {
        required: true,
        type: String
    },
  })

  module.exports = mongoose.model('coach_profle', coachprofileSchema)