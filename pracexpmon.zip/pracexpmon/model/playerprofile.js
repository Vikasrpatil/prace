const mongoose = require('mongoose');


const playerprofileSchema = new mongoose.Schema({
    position: {
        required: true,
        type: String
    },
    height: {
        required: true,
        type: Number
    },
    weight: {
        required: true,
        type: Number
    },
    phone: {
        required: true,
        type: Number
    },
    admin_right: {
        required: true,
        type: Boolean
    },
    assign_team: {
        required: true,
        type: String
    },
    jersey_number: {
        required: true,
        type: Number
    },
  })

  module.exports = mongoose.model('player_profile', playerprofileSchema)