const mongoose = require('mongoose');

var validateEmail = function(email) {
    var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return re.test(email)
};

const dataSchema = new mongoose.Schema({
    username: {
        required: true,
        type: String
    },
    role: {
        required: true,
        type: String
    },
    age: {
        required: true,
        type: Number
    },
    assign_team: {
        required: true,
        type: String
    },
    chinese_name: {
        required: true,
        type: String
    },
    english_name: {
        required: true,
        type: String
    },
    user_id: {
        type: Number,
        ref:'coach_profle'
    },
    firebase_user_id:{
        required:true,
        type:String
    },
    email:{
        type: String,
        trim: true,
        lowercase: true,
        unique: true,
        required: 'Email address is required',
        validate: [validateEmail, 'Please fill a valid email address'],
        match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please fill a valid email address']
    },
    date_of_birth:{
        type:Date,
        required:false
    }


})


module.exports = mongoose.model('user', dataSchema)

