const mongoose = require('mongoose');


const activitySchema = new mongoose.Schema({
    type: {
        required: true,
        type: String
    },
    pact: {
        required: true,
        type: String
    },
    player_list: {
        required: true,
        type: Array
    },
    date: {
        required: true,
        type: String
    },

    due_date: {
        required: true,
        type: String
    },
    end_date: {
        required: true,
        type: String
    }
  })

  module.exports = mongoose.model('activity', activitySchema)