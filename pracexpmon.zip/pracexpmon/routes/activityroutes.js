const express = require('express');

const router = express.Router();

const auth = require('../middleware/auth');

const Model = require('../model/activity');

module.exports = router;

router.post('/post', async (req, res) => {
    const Activity = new Model({
        type: req.body.type,
        pact:req.body.pact,
        player_list: req.body.player_list,
        date:req.body.date,
        due_date:req.body.due_date,
        end_date:req.body.end_date,
        })
   
    try {
        const activitySave = await Activity.save();
       
        res.status(200).json(activitySave)
    }
    catch (error) {
        res.status(400).json({message: error.message})
    }
})

//Get all Method
router.get('/getAll', async (req, res) => {
    try{
        const Team = await Model.find();
        res.json(Team)
    }
    catch(error){
        res.status(500).json({message: error.message})
    }
})

//Get by ID Method
router.get('/getOne/:id', async (req, res) => {
    try{
        const data = await Model.findById(req.params.id);
        res.json(data)
    }
    catch(error){
        res.status(500).json({message: error.message})
    }
})

//Update by ID Method
router.patch('/update/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const updatedData = req.body;
        const options = { new: true };

        const result = await Model.findByIdAndUpdate(
            id, updatedData, options
        )

        res.send(result)
    }
    catch (error) {
        res.status(400).json({ message: error.message })
    }
})

//Delete by ID Method
router.delete('/delete/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const data = await Model.findByIdAndDelete(id)
        res.send(`Document with ${data.name} has been deleted..`)
    }
    catch (error) {
        res.status(400).json({ message: error.message })
    }
})