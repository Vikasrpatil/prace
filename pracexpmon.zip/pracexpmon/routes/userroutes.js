const express = require('express');

const router = express.Router();

const auth = require('../middleware/auth');

const Model = require('../model/user');


module.exports = router;

router.post('/post', async (req, res) => {
    const User = new Model({
        username: req.body.username,
        role:req.body.role,
        age: req.body.age,
        assign_team:req.body.assign_team,
        chinese_name:req.body.chinese_name,
        english_name:req.body.english_name,
        user_id:req.body.user_id,
        firebase_user_id:req.body.firebase_user_id,
        email:req.body.email,
        date_of_birth:req.body.date_of_birth
    })
   
    
  

   
    try {
        const dataToSave = await User.save();
       
        res.status(200).json(dataToSave)
    }
    catch (error) {
        res.status(400).json({message: error.message})
    }
})




//Get all Method
router.get('/getAll', async (req, res) => {
    try{
        const User = await Model.find();
        res.json(User)
    }
    catch(error){
        res.status(500).json({message: error.message})
    }
})


//Get by ID Method
router.get('/getOne/:id', async (req, res) => {
    try{
        const data = await Model.findById(req.params.id);
        res.json(data)
    }
    catch(error){
        res.status(500).json({message: error.message})
    }
})

//Update by ID Method
router.patch('/update/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const updatedData = req.body;
        const options = { new: true };

        const result = await Model.findByIdAndUpdate(
            id, updatedData, options
        )

        res.send(result)
    }
    catch (error) {
        res.status(400).json({ message: error.message })
    }
})

//Delete by ID Method
router.delete('/delete/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const data = await Model.findByIdAndDelete(id)
        res.send(`Document with ${data.username} has been deleted..`)
    }
    catch (error) {
        res.status(400).json({ message: error.message })
    }
})